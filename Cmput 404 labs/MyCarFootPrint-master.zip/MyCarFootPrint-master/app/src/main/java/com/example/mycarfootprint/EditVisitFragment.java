package com.example.mycarfootprint;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.time.LocalDate;

public class EditVisitFragment extends DialogFragment {
    interface EditVisitDialogListener {
        void editVisit(Visit visit, int position);
        void addVisit(Visit visit);
        void deleteVisit(int position);
    }

    private EditVisitDialogListener listener;
    private boolean editMode;
    private String actionText;
    private Visit visitInitial;
    private int visitIndex;

    //when this constructor is called the fragment will act as an editor
    public EditVisitFragment(Visit targetVisit, int position) {
        super();
        visitInitial = targetVisit;
        // make edited a copy so editing it doesn't mess with original
        editMode = true;
        actionText = "Edit";
        visitIndex = position;
    }

    //when this constructor is called the fragment will act as a creator
    public EditVisitFragment() {
        super();
        visitInitial = new Visit();
        editMode = false;
        actionText = "Create";
        visitIndex = -1;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof EditVisitDialogListener) {
            listener = (EditVisitDialogListener) context;
        } else {
            throw new RuntimeException(context + " must implement editVisitDialogListener");
        }

    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_edit_visit, null);
        // get references to all the views
        EditText editStationName = view.findViewById(R.id.edit_text_station_name);
        EditText editGasAmount = view.findViewById(R.id.edit_text_gas_amount);
        EditText editGasPrice = view.findViewById(R.id.edit_text_gas_price);
        DatePicker editDate = view.findViewById(R.id.date_picker_visit_date);
        RadioButton radioGasoline = view.findViewById(R.id.radio_button_gasoline);
        RadioButton radioDiesel = view.findViewById(R.id.radio_button_diesel);

        //set initial values of the views
        editStationName.setText(visitInitial.getStationName());
        editGasAmount.setText(Integer.toString(visitInitial.getFuelAmount()));
        editGasPrice.setText(String.format("%.2f", visitInitial.getFuelPrice()));
        LocalDate initialDate = visitInitial.getDate();
        editDate.updateDate(initialDate.getYear(), initialDate.getMonthValue() - 1, initialDate.getDayOfMonth());
        if (visitInitial.getFuelType().equals("gasoline")) {
            radioGasoline.setChecked(true);
        } else {
            radioDiesel.setChecked(true);
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        // if working on an existing visit, add a delete button
        if (editMode) {
            builder.setNeutralButton("Delete", (dialog, which) -> {
                listener.deleteVisit(visitIndex);
            });
        }
        return builder
            .setView(view)
            .setTitle(actionText + " a Visit")
            .setPositiveButton(actionText, (dialog, which) -> {
                String stationName = editStationName.getText().toString();
                int fuelAmount = Math.round(Float.parseFloat(editGasAmount.getText().toString()));
                double fuelPrice = Double.parseDouble(editGasPrice.getText().toString());
                int year = editDate.getYear();
                int month = editDate.getMonth() + 1;
                int day = editDate.getDayOfMonth();
                String fuelType = radioGasoline.isChecked() ? "gasoline" : "diesel";
                Visit visit = new Visit(stationName, fuelAmount, fuelPrice,  fuelType, LocalDate.of(year, month, day));
                if (editMode) {
                    listener.editVisit(visit, visitIndex);
                } else {
                    listener.addVisit(visit);
                }
            })
            .setNegativeButton("Cancel", (dialog, which) -> {
                // do nothing
            })
            .create();

    }
}
