package com.example.mycarfootprint;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.view.LayoutInflater;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class VisitArrayAdapter extends ArrayAdapter<Visit> {

    public VisitArrayAdapter(Context context, ArrayList<Visit> visits) {
        super(context, 0, visits);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view;
        if (convertView == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.station_list_content,
                    parent, false);
        } else {
            view = convertView;
        }
        Visit visit = getItem(position);
        //get view of each dynamic text view
        TextView stationName = view.findViewById(R.id.station_name_text);
        TextView fuelType = view.findViewById(R.id.fuel_type_text);
        TextView footprint = view.findViewById(R.id.footprint_text);
        TextView cost = view.findViewById(R.id.cost_text);
        TextView visitDate = view.findViewById(R.id.date_text);

        //set text of each dynamic text view
        stationName.setText(visit.getStationName());
        fuelType.setText(visit.getFuelType());
        footprint.setText(Integer.toString(Math.round(visit.getFootprint())) + " kg CO2");
        cost.setText(String.format("$%.2f", visit.getCost()));
        visitDate.setText(visit.getDate().toString());

        return view;
    }
}
