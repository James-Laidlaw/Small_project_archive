package com.example.mycarfootprint;

import java.time.LocalDate;

public class Visit {
    private String stationName;
    private int fuelAmount;
    private double fuelPrice;
    //This will always be "gasoline" or "diesel"
    private String fuelType;
    private LocalDate date;

    public Visit() {
        stationName = "";
        fuelAmount = 0;
        fuelPrice = 0.0;
        fuelType = "gasoline";
        date = LocalDate.now();

    }

    public Visit(String stationName, int fuelAmount, double fuelPrice, String fuelType, LocalDate date) {
        // uses inbuilt setters for some values for validation and avoid referencing private variables
        this.stationName = stationName;
        setFuelAmount(fuelAmount);
        setFuelPrice(fuelPrice);
        setFuelType(fuelType);
        setDate(date);
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public int getFuelAmount() {
        return fuelAmount;
    }

    public void setFuelAmount(int fuelAmount) {
        this.fuelAmount = Math.max(fuelAmount, 0);
    }

    public double getFuelPrice() {
        return fuelPrice;
    }

    public void setFuelPrice(double fuelPrice) {
        //ensure that the price is positive
        if (fuelPrice >= 0.0) {
            // round to 2 decimal places before storing
            this.fuelPrice = Math.round(fuelPrice * 100.0) / 100.0;
        } else {
            this.fuelPrice = 0.0;
        }
    }
    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        if (fuelType.equals("gasoline") || fuelType.equals("diesel")) {
            this.fuelType = fuelType;
        } else {
            //default to gasoline on invalid input
            this.fuelType = "gasoline";
        }
    }

    public LocalDate getDate() {
        //return a copy to avoid reference issues
        return LocalDate.of(date.getYear(), date.getMonthValue(), date.getDayOfMonth());
    }

    public void setDate(LocalDate date) {
        //set to a copy to avoid reference issues
        this.date = LocalDate.of(date.getYear(), date.getMonthValue(), date.getDayOfMonth());
    }

    public double getCost() {
        // calculate cost to 2 decimal places
        return Math.round(fuelAmount * fuelPrice * 100.0) / 100.0;
    }

    public float getFootprint() {
        if (fuelType.equals("gasoline")) {
            return Math.round(fuelAmount * 2.32);
        } else if (fuelType.equals("diesel")){
            return Math.round(fuelAmount * 2.69);
        } else {
            //raise an error
            throw new IllegalArgumentException("Fuel type must be either 'gasoline' or 'diesel', Somehow it is not");
        }
    }
}
