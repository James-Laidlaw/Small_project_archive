// made by James Laidlaw, started 2023-01-28
// I have not collaborated directly with anyone on this project
// Large amount of code based on previous lab project "ListyCity",
// which contains the code provided by the lab instructor
// Referenced various pages of Geeks4Geeks, JavatPoint.com, and developer.android.com
// for help with syntax throughout the project; major code snippets and
// heavily referenced pages are listed above their relevant sections
// github copilot was on, but no suggestions were taken directly,
// however i cannot promise it did not influence my code.
package com.example.mycarfootprint;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.sql.Array;
import java.time.LocalDate;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements EditVisitFragment.EditVisitDialogListener {

    private ArrayList<Visit> visitDataList;

    private ListView visitList;

    private VisitArrayAdapter visitAdapter;

    public void addVisit(Visit visit) {
        visitDataList.add(visit);
        visitAdapter.notifyDataSetChanged();
        updateTotals();
    }

    public void editVisit(Visit visit, int position) {
        visitDataList.set(position, visit);
        visitAdapter.notifyDataSetChanged();
        updateTotals();
    }

    public void deleteVisit(int position) {
        visitDataList.remove(position);
        visitAdapter.notifyDataSetChanged();
        updateTotals();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        visitDataList = new ArrayList<Visit>();

        visitList = findViewById(R.id.visit_list);
        visitAdapter = new VisitArrayAdapter(this, visitDataList);
        visitList.setAdapter(visitAdapter);

        FloatingActionButton fab = findViewById(R.id.button_add_visit);
        fab.setOnClickListener(view -> {
            new EditVisitFragment().show(getSupportFragmentManager(), "Add Visit");
        });

        visitList.setOnItemClickListener((parent, view, position, id) -> {
            Visit visit = visitDataList.get(position);
            EditVisitFragment editVisitFragment = new EditVisitFragment(visit, position);
            editVisitFragment.show(getSupportFragmentManager(), "Edit Visit");
        });
        updateTotals();

    }

    private void updateTotals() {
        double totalFootprint = 0;
        double totalCost = 0;
        for (Visit visit : visitDataList) {
            totalFootprint += visit.getFootprint();
            totalCost += visit.getCost();
        }
        long roundedFootprint = Math.round(totalFootprint);


        TextView totalDistanceView = findViewById(R.id.text_total_footprint);
        TextView totalCostView = findViewById(R.id.text_total_cost);
        // string formatting information from https://www.javatpoint.com/java-string-format
        totalDistanceView.setText(String.format("%d kg CO2", roundedFootprint));
        totalCostView.setText(String.format("$%.2f", totalCost));
    }
}