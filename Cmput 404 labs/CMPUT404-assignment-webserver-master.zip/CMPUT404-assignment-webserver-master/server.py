#  coding: utf-8
import socketserver
import time
import os

# Copyright 2023 James Laidlaw
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Derivattive of https://github.com/abramhindle/CMPUT404-assignment-webserver,
# also distributed under the Apache License, Version 2.0.
#
# Furthermore it is derived from the Python documentation examples thus
# some of the code is Copyright © 2001-2013 Python Software
# Foundation; All Rights Reserved
#
# http://docs.python.org/2/library/socketserver.html
#
# run: python freetests.py

# HTTP response texts primarily based off MDN docs, https://developer.mozilla.org/en-US/docs/Web/HTTP/Status

# try: curl -v -X GET http://127.0.0.1:8080/


class MyWebServer(socketserver.BaseRequestHandler):
    accessibleArea = os.path.join(os.getcwd(), "www")
    logging = False

    # custom print function that adds timestamp, loosely based off https://stackoverflow.com/questions/415511/how-do-i-get-the-current-time
    def log(self, text: str):
        if self.logging:
            print(time.strftime("%H:%M:%S") + "> " + text)

    # based vaugely on https://stackoverflow.com/questions/3812849/how-to-check-whether-a-directory-is-a-sub-directory-of-another-directory
    def checkInBounds(self, path: str):
        commonPath = os.path.commonprefix([self.accessibleArea, path])
        return commonPath == self.accessibleArea

    # converts relative path to absolute path based on accessible area
    def getFullPath(self, relativePath: str):
        # concat accessible area and relative path, then resolve any duplicate "/"'s, navigations (/../), etc with normpath()
        path = self.accessibleArea + relativePath
        path = os.path.normpath(path)  # resolves navigation
        return path
    
    def reqProcessor(self, requestString: str) -> str:
        requestSegments = requestString.split()
        method = requestSegments[0]
        path = requestSegments[1]

        # if the request method is not get, return 405
        if method != "GET":
            self.log("method is not allowed, return 405. Attempted method: " + method)
            return "HTTP/1.1 405 Method Not Allowed"

        # verify path legal
        targetPath = self.getFullPath(path)
        if self.checkInBounds(targetPath) == False:
            self.log("path is not legal, return 404. Attempted path: " + path)
            return "HTTP/1.1 404 Not Found"

        #search for requested file
        fileFound = False
        fileType = ""
        fileContent = ""
        # if path is a directory, check for index.html
        if os.path.isdir(targetPath):
            # verify directory has closing /, otherwise redirect with closing /
            if path[-1] != "/":
                self.log(
                    "path not formatted correctly, redirecting. Attempted path: " + path
                )
                return "HTTP/1.1 301 Moved Permanently \n\r Location: " + path + "/"

            indexPath = os.path.join(targetPath, "index.html")
            self.log("path is a directory, checking for index")
            if os.path.isfile(indexPath):
                self.log("found index.html")
                fileFound = True
                fileType = "html"
                file = open(indexPath, "r")
                fileContent = file.read()

        # if path is a file, read file
        if os.path.isfile(targetPath):
            self.log("path is a file, reading file")
            fileFound = True
            fileType = targetPath.split(".")[-1]
            file = open(targetPath, "r")
            fileContent = file.read()

        if fileFound:

            # make sure .htm is also labeled as html 
            # (found this possibility on https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types)
            if fileType == "htm":
                fileType = "html"

            self.log("sending 200 & file content")
            contentSize = len(fileContent.encode("utf-8"))
            # fstring modified from chatGPT (GPT3.5) "can you write a python fstring for  HTML 1.1 response 200 OK with content, content type, and content length?"
            # for some reason the tests fail if /n/r is used instead of /r/n for the first line
            return f"HTTP/1.1 200 OK\r\nContent-Type: text/{fileType}\r\nContent-Length:{contentSize}\r\n\r\n{fileContent}\r\n"
        else:
            self.log("couldnt find file, sending 404")
            return "HTTP/1.1 404 Not Found"

    def handle(self):
        self.data = self.request.recv(1024).strip()
        self.log("Got a request of: %s\n" % self.data)

        # get the request method and path
        requestString: str = self.data.decode()

        response = self.reqProcessor(requestString)

        self.request.sendall(bytearray(response, "utf-8"))
        return


if __name__ == "__main__":
    HOST, PORT = "localhost", 8080

    socketserver.TCPServer.allow_reuse_address = True
    # Create the server, binding to localhost on port 8080
    server = socketserver.TCPServer((HOST, PORT), MyWebServer)

    # Activate the server; this will keep running until you
    # interrupt the program with Ctrl-C
    server.serve_forever()
