#!/usr/bin/env python3
# coding: utf-8
# Copyright 2016 James Laidlaw, Abraham Hindle, https://github.com/tywtyw2002, and https://github.com/treedust
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Do not use urllib's HTTP GET and POST mechanisms.
# Write your own HTTP GET and POST
# The point is to understand what you have to send and get experience with it
import sys
import socket
import re
# you may use urllib to encode data appropriately
import urllib.parse

def help():
    print("httpclient.py [GET/POST] [URL]\n")

class HTTPResponse(object):
    def __init__(self, code=200, body=""):
        self.code = code
        self.body = body

class HTTPClient(object):
    #def get_host_port(self,url):

    def connect(self, host, port):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect((host, port))
        return None

    def get_code(self, data) -> int:
        # get first line of response
        first_line = data.split('\r\n')[0]

        # HTTP code should be the second word
        code = first_line.split(' ')[1]
        return int(code)

    def get_headers(self,data) -> dict[str, str]:
        #headers should be all lines after the first until the double newline
        data_lines = data.split('\r\n')
        data_lines.pop(0)

        headers = {}
        current_line = data_lines.pop(0)
        while current_line != '':
            key, value = current_line.split(': ')
            headers[key] = value

        return headers

    def get_body(self, data) -> str:
        # body should be everything after the double newline
        data_lines = data.split('\r\n\r\n')
        return data_lines[1]
    
    def sendall(self, data):
        self.socket.sendall(data.encode('utf-8'))
        
    def close(self):
        self.socket.close()

    # read everything from the socket
    def recvall(self, sock):
        buffer = bytearray()
        done = False
        while not done:
            part = sock.recv(1024)
            if (part):
                buffer.extend(part)
            else:
                done = not part
        return buffer.decode('utf-8')


    def formContent(self, args: dict[str, str]) -> str:

        content = ""
        if args != None:
            for key, value in args.items():
                # content format based on https://stackoverflow.com/questions/21195956/format-of-an-http-get-request
                content += "%s=%s&" % (key, value)
            content =  content[0:-1] # strip trailing "&"

        content_section = "\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: %d\r\n\r\n%s" % (len(content), content)

        return content_section

    def request(self, url, method, args=None) -> HTTPResponse:
        parsed_url = urllib.parse.urlparse(url)

        # default port to 80 if not specified
        port = parsed_url.port
        if port == None:
            port = 80
        
        self.connect(parsed_url.hostname, port)

        path = parsed_url.path
        if (path == ""):
            path = "/"

        content_section = self.formContent(args)

        # send get request
        # format based on https://stackoverflow.com/questions/34192093/python-socket-get
        request = "%s %s HTTP/1.1\r\nHost: %s\r\nConnection: close%s" % (method, path, parsed_url.hostname, content_section)

        self.socket.sendall(bytearray(request, 'utf-8'))

        response = self.recvall(self.socket)

        self.close()
        
        code = self.get_code(response)
        body = self.get_body(response)
        return HTTPResponse(code, body)

    def GET(self, url, args=None):
        print("CLIENT GET %s\n" % url)
        return self.request(url, "GET", args)

    def POST(self, url, args=None):
        print("CLIENT POST %s\n" % url)
        return self.request(url, "POST", args)

    def command(self, url, command="GET", args=None):
        if (command == "POST"):
            return self.POST( url, args )
        else:
            return self.GET( url, args )
    
if __name__ == "__main__":
    client = HTTPClient()
    command = "GET"
    if (len(sys.argv) <= 1):
        help()
        sys.exit(1)
    elif (len(sys.argv) == 3):
        pass
        # print(client.command( sys.argv[2], sys.argv[1] ))
    else:
        pass
        # print(client.command( sys.argv[1] ))
