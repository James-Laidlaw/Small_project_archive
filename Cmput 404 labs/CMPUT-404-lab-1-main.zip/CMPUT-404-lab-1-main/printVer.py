import requests

print(requests.__version__)


